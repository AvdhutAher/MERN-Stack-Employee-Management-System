const mongoose = require('mongoose');
 const Schema = mongoose.Schema;
 
 // List of columns for Employee schema
 let Employee = new Schema({
 
 code : {
 type : String,
 required : true
 }, 
 designation : {
 type : String,
 required : true
 } , 

 name: {
 type: String,
 required : true
 },

 packageAnum: {
 type: String,
 required : true
 },
 phone: {
    type: Number,
    required : true
 },
 joinedDate : {
     type : String,
     required : true
 },
 image : {
     type : String,
     required : false
     
 },
 email: {
 type: String

 }

 },{
 collection: 'employees'
 });
 
 module.exports = mongoose.model('Employee', Employee);