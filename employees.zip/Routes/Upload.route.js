const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');

let employeeModel = require('../Model/Employee');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images');
    },

    filename: (req, file, cb) => {
        cb(null, file.originalname)
    }
});



const imageFileFilter = (req, file, cb) => {
    if(!file.originalname.match(/\.(jpg|png)$/)) {
        return cb(new Error('You can upload only Jpg or Png image files!'), false);
    }
    cb(null, true);
};




const upload = multer({ storage: storage, fileFilter: imageFileFilter});

const uploadRoute = express.Router();

uploadRoute.use(bodyParser.json());




//uploadRouter.route('/')

// .post(authenticate.verifyUser,  upload.single('imageFile'), (req, res) => {
//     res.statusCode = 200;
//     res.setHeader('Content-Type', 'application/json');
//     res.json(req.file);
// })


// uploadRoute.route('/').post( upload.single('imageFile'), function (req, res) {
//     res.statusCode = 200;
//     res.setHeader('Content-Type', 'application/json');
//     res.json(req.file);
// })



uploadRoute.route('/').post(function (req, res) {
    employeeModel.findById(req.params.id, function (err, employee) {
    if (!employee)
    return next(new Error('Unable To Find Employee With This Id'));
    else {
  
    upload.image = req.body.image;

    
    employee.save().then(emp => {
    res.json('img Updated Successfully');
    })
    .catch(err => {
    res.status(400).send("Unable To Update img");
    });
    }
    });
    });




    module.exports = uploadRoute;