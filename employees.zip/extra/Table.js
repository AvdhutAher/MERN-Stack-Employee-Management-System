import React from "react";
import axios from 'axios';

import UserRows from "./UserRows";
import ListEmployee from './ListEmployee';
// import API from "../utils/API.js";
import "./table.css";
import SearchBar from './SearchBar';

class Table extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [],
      searchedUser: [],
      sortDir: "asc",
      userSearch: event => {
        console.log(event.target.value);
        const filter = event.target.value;
        const searchedResults = this.state.users.filter(item => {
          let values = Object.values(item)
            .join("")
            .toLowerCase();
          return values.indexOf(filter.toLowerCase()) !== -1;
        });
        this.setState({ searchedUser: searchedResults });
        console.log(searchedResults);
      }
    };
    this.sortBy = this.sortBy.bind(this);
  }





  componentDidMount() {
    // API.randomUsers().then(answer => {
    //   console.log(answer.data.results);
    //   this.setState({ users: answer.data.results, searchedUser: answer.data.results });
    // });
    //this.getEmployeeList();


    // To get all the employees
   
    axios.get('http://localhost:4000/employees')
    .then((response) => {
    console.log(response);
    this.setState({
    users: response.data,  searchedUser: response.data
    });
    })
    .catch((error) => {
    console.log(error);
    })
    



  }


    
    // To delete any employee
    deleteEmployee(empid) {
    this.employeeService.deleteEmployee(empid);
    this.getEmployeeList();
    }


  sortBy(key, data) {
    console.log(key);
    this.setState({
      users: data.sort((a, b) => { 
        if (key === 'code') {
          if (this.state.sortDir === "asc") {
            return a.phone.localeCompare(b.code);
          } else {
            return b.phone.localeCompare(a.code);
          }
        }
        if (key === 'name') {
          if (this.state.sortDir === "asc") {
            return a.name.localeCompare(b.name);
          } else {
            return b.name.localeCompare(a.name);
          }
        }
        if (key === 'phone') {
          if (this.state.sortDir === "asc") {
            return a.phone.localeCompare(b.phone);
          } else {
            return b.phonr.localeCompare(a.phone);
          }
        }
      }
       )
    });
    this.setState({ sortDir: this.state.sortDir === "asc" ? "desc" : "asc" });
  }



  render() {
    return (
    <div className="container">
      <SearchBar userSearch={this.state.userSearch}/>
      <div className="table-responsive">
        <table id="users" className="table">
          <thead>
            <tr>
              
              <th className="sort" onClick={() => this.sortBy("code", this.state.searchedUser)}>Code</th>
              <th className="sort" onClick={() => this.sortBy("name", this.state.searchedUser)}>Name</th>
              <th>Package</th>
              <th className="sort" onClick={() => this.sortBy("phone", this.state.searchedUser)}>Phone</th>
              <th>Joined Date</th>
              <th>Image</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            <ListEmployee users={this.state.searchedUser} />
          </tbody>
        </table>
      </div>
    </div>
    );
  }
}
export default Table;