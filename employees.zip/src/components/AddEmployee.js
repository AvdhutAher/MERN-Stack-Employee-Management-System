import React, { Component } from 'react';
import axios from 'axios';
//import Button from 'react-bootstrap/Button';
// Import Datepicker
// import ReactDatePicker from 'react-date-picker-cs';
// import Date from './Date'

// import Calendar from 'react-input-calendar'






// or less ideally
import { Button } from 'react-bootstrap';

const customStyle = {
width: '300px',
margin: '0 auto'
}

class AddEmployee extends Component {
constructor(props) {
super(props);
this.state = {
code: '',
designation: '',
name: '',
package: '',
phone: '',
joinedDate: '',
image : '',
email: '',

}
}

// When value changes of the fields
handleChange = (event) => {
this.setState({ [event.target.name]: event.target.value });
}

// To add new employee when user submits the form
handleSubmit = (event) => {
event.preventDefault();
const { code, designation, name, packageAnum, phone, joinedDate, image, email } = this.state;


if (!Number(phone)) {
  alert(" phone field must be a number");
} 
else if(code =="" || designation =="" || name== "" || packageAnum == "" || joinedDate== "" || email==""){
    alert(" Fill the All Required Fields");
}

else{


 
axios.post('http://localhost:4000/employees/addEmployee', {

code: code,
designation: designation,
name: name,
packageAnum: packageAnum,
phone: phone,
joinedDate: joinedDate,
image : image,
email: email,

})
.then((response) => {
console.log(response);
this.props.history.push('/');
})
.catch((error) => {
console.log(error);
});
}

alert(" Emplolyee Data Submitted Succesfully ");
}









render() {
return (
<div className="container">
<form style={customStyle} onSubmit={this.handleSubmit}>


<label>
code
<input
name="code"
type="text"
value={this.state.code}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
Designation
<input
name="designation"
type="text"
value={this.state.designation}
onChange={this.handleChange}
className="form-control"
/>
</label>



<label>
Name
<input
name="name"
type="text"
value={this.state.name}
onChange={this.handleChange}
className="form-control"/>
</label>


<label>
Package
<input
name="packageAnum"
type="text"
value={this.state.packageAnum}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
Phone No
<input
name="phone"
type="text"
value={this.state.phone}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
JoinedDate
<input
name="joinedDate"
type="text"
value={this.state.joinedDate}
onChange={this.handleChange}
className="form-control"
/>
</label>

{/* <Calendar format='DD/MM/YYYY' date='4-12-2014' /> */}



<br />

{/* <label>
Image
<input
name="image"
type="file"
id = "image"
value={this.state.image}
onChange={this.handleChange}
className="form-control"
/>
</label> */}

{/* 
<label for="image">Upload Image</label> 
                <input type="file" id="image" 
                       name="image" value="" required> */}

<br />

<label>
Email
<input
name="email"
type="text"
value={this.state.email}
onChange={this.handleChange}
className="form-control"
/>
</label>

<br />



<br />

<input
type="submit"
value="submit"
className="btn btn-primary"
/>
</form>
</div>
);
}
}

export default AddEmployee;