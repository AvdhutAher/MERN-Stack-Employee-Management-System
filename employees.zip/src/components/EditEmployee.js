import React, { Component } from 'react';
 import axios from 'axios';
 
 const customStyle = {
 width: '300px',
 margin: '0 auto'
 }
 
 class EditEmployee extends Component {
 constructor(props) {
 super(props);
 this.state = {

 code: '',
 designation: '',
 name: '',
 packageAnum: '',
 phone: '',
 joinedDate: '',
 email: ''

 }
 }
 
 componentDidMount = () => {
 this.getEmployeeById();
 }
 
 // To get employee based on ID
 getEmployeeById() {
 axios.get('http://localhost:4000/employees/editEmployee/' + this.props.match.params.id)
 .then((response) => {
 this.setState({
     code : response.data.code,
     designation : response.data.designation,
     name: response.data.name,
     packageAnum : response.data.packageAnum,
     phone : response.data.phone,
     joinedDate : response.data.joinedDate,
     image : response.data.image,
     email: response.data.email,

 });
 })
 .catch((error) => {
 console.log(error);
 })
 }
 
 handleChange = (event) => {
 this.setState({ [event.target.name]: event.target.value });
 }
 
 // To update the record on submit
 handleSubmit = (event) => {
 event.preventDefault();
 const { code, designation, name, packageAnum, phone, joinedDate, email  } = this.state;

 if (!Number(phone)) {
    alert(" phone field must be a number");
  }
  
 else if(code =="" || designation =="" || name== "" || packageAnum == "" || joinedDate== ""|| email==""){
      alert(" Fill the All Required Fields");
  }

else{


 axios.post('http://localhost:4000/employees/updateEmployee/' + this.props.match.params.id, {

 code: code,
 designation: designation,
 name: name,
 packageAnum: packageAnum,
 phone: phone,
 joinedDate: joinedDate,
 email: email,

 })
 .then((response) => {
 console.log(response);
 this.props.history.push('/');
 })
 .catch((error) => {
 console.log(error);
 });
 
 }

 alert(" Emplolyee Data Submitted Succesfully ");

}
 
 render() {
 return (
<div className="container">
<form style={customStyle} onSubmit={this.handleSubmit}>


<label>
code
<input
name="code"
type="text"
value={this.state.code}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
Designation
<input
name="designation"
type="text"
value={this.state.designation}
onChange={this.handleChange}
className="form-control"
/>
</label>




<label>
Name
<input
name="name"
type="text"
value={this.state.name}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
Package
<input
name="packageAnum"
type="text"
value={this.state.packageAnum}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
Phone No
<input
name="phone"
type="text"
value={this.state.phone}
onChange={this.handleChange}
className="form-control"
/>
</label>


<label>
JoinedDate
<input
name="joinedDate"
type="text"
value={this.state.joinedDate}
onChange={this.handleChange}
className="form-control"
/>
</label>


<br />

{/* <label>
Image
<input
name="image"
type="file"
id = "image"
value={this.state.image}
onChange={this.handleChange}
className="form-control"
/>
</label> */}

{/* 
<label for="image">Upload Image</label> 
                <input type="file" id="image" 
                       name="image" value="" required> */}

<br />

<label>
Email
<input
name="email"
type="text"
value={this.state.email}
onChange={this.handleChange}
className="form-control"
/>
</label>

<br />



<br />

<input
type="submit"
value="submit"
className="btn btn-primary"
/>
</form>
</div>
);
}
}
 
 export default EditEmployee;