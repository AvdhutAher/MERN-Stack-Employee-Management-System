import React, { Component } from 'react';
import { Navbar, Nav, NavItem } from 'react-bootstrap';
// To use routing functionalities
import { Link } from 'react-router-dom';
import '../index.css';

class Header extends Component {
render() {
return (
<div>



<div>
<Link to="/"><button className="btn btn-primary" style={{marginLeft: "100px" , marginTop: "20px"}} >  Home</button></Link>

<Link to="/addEmployee"> <button  onClick={"/addEmployee"}className="btn btn-primary" style={{marginLeft: "100px" , marginTop: "20px"}} href="/addEmployee"> Add Employee </button></Link>

</div>









</div>
);
}
}
export default Header;








// <Navbar bg="light" expand="lg">
//   <Navbar.Brand href="#home">Employee Managment Sytem </Navbar.Brand>

//   <Navbar.Collapse id="basic-navbar-nav">
//     <Nav className="mr-auto" >
//       <Nav.Link href="/" >Home  </Nav.Link>
//       <Nav.Link href="/addEmployee">Add new Employee  </Nav.Link>
    
//     </Nav>
  
//   </Navbar.Collapse>
// </Navbar>